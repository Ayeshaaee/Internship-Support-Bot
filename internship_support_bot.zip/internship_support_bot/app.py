import tkinter as tk
from tkinter import scrolledtext
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def load_knowledge_base(filename="knowledge_base.txt"):
    questions = []
    answers = []
    with open(filename, "r", encoding="utf-8") as f:
        content = f.read().split("\n")
        for line in content:
            if line.startswith("Q:"):
                questions.append(line.replace("Q:", "").strip())
            elif line.startswith("A:"):
                answers.append(line.replace("A:", "").strip())
    return questions, answers

questions, answers = load_knowledge_base()

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(questions)

def chatbot_response(user_input):
    user_vec = vectorizer.transform([user_input])
    similarity = cosine_similarity(user_vec, X)
    idx = similarity.argmax()
    if similarity[0][idx] < 0.2:
        return "Sorry, I don’t know the answer to that."
    return answers[idx]

def send_message(event=None):
    user_msg = entry.get()
    if user_msg.strip() == "" or user_msg == placeholder_text:
        return
    chat_window.config(state=tk.NORMAL)
    chat_window.insert(tk.END, "👤 " + user_msg + "\n", "user")
    entry.delete(0, tk.END)

    bot_msg = chatbot_response(user_msg)
    chat_window.insert(tk.END, "🤖 " + bot_msg + "\n", "bot")
    chat_window.config(state=tk.DISABLED)
    chat_window.see(tk.END)

def on_entry_click(event):
    if entry.get() == placeholder_text:
        entry.delete(0, tk.END)
        entry.config(fg="black")

def on_focusout(event):
    if entry.get() == "":
        entry.insert(0, placeholder_text)
        entry.config(fg="grey")

root = tk.Tk()
root.title("Internship FAQ Chatbot")
root.geometry("500x500")
root.configure(bg="#934790")  

chat_window = scrolledtext.ScrolledText(root, wrap=tk.WORD, state=tk.DISABLED, width=100, height=20, bg="#FFDEE9", font=("Arial", 12))
chat_window.pack(pady=10)

chat_window.tag_config("user", foreground="#FF0066")   
chat_window.tag_config("bot", foreground="#6A0066")    

frame = tk.Frame(root, bg="#FFDEE9")
frame.pack(pady=5)

placeholder_text = "Type here your queries..."
entry = tk.Entry(frame, width=40, font=("Arial", 12), fg="grey")
entry.insert(0, placeholder_text)
entry.bind("<FocusIn>", on_entry_click)
entry.bind("<FocusOut>", on_focusout)
entry.bind("<Return>", send_message)  
entry.pack(side=tk.LEFT, padx=5)

send_btn = tk.Button(frame, text="➤", command=send_message, bg="#92DFF3", fg="black")
send_btn.pack(side=tk.RIGHT)

chat_window.config(state=tk.NORMAL)
chat_window.insert(tk.END, "🤖 Hi! I'm your internship support bot. Ask away! 🙂\n", "bot")
chat_window.config(state=tk.DISABLED)

root.mainloop()
